package com.techprimers.designpatterns.facade;

public interface Phone {

    String build();
}
