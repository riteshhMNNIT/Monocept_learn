package com.techprimers.designpatterns.decorator;

public interface Phone {

    String build();
}
