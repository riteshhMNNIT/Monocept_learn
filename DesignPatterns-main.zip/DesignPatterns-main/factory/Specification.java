package com.techprimers.designpatterns.factory;

public interface Specification {

     void description();

}
