package com.techprimers.designpatterns.factory;

public class AndroidPanel implements Specification {
    public void description() {
        System.out.println("Sandstone finish");
    }


}
