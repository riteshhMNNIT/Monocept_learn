package com.techprimers.designpatterns.factory;

public enum  PhoneType {
    ANDROID,
    IPHONE
}
