package com.techprimers.designpatterns.factory;

public class AndroiProcessor implements Specification {
    public void description() {
        System.out.println("Snapdragon 625");
    }
}
