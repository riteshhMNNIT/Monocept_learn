package com.techprimers.designpatterns.factory;

public class IPhoneProcessor implements Specification {
    public void description() {
        System.out.println("A10 Chip");
    }
}
