package com.techprimers.designpatterns.factory;

public class IPhoneCamera implements Specification {
    public void description() {
        System.out.println("16MP");
    }
}
