package com.techprimers.designpatterns.factory;

public class AndroidCamera implements Specification {
    public void description() {
        System.out.println("12 MP Camera");
    }
}
