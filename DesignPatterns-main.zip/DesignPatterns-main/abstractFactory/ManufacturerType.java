package com.techprimers.designpatterns.abstractfactory;

public enum ManufacturerType {

    LENOVO,
    GOOGLE,
    ONEPLUS,
    MICROSOFT
}
