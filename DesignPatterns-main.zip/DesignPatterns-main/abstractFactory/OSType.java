package com.techprimers.designpatterns.abstractfactory;

public enum  OSType {

    WINDOWS,
    ANDROID
}
