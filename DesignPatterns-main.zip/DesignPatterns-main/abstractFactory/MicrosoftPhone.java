package com.techprimers.designpatterns.abstractfactory;

public class MicrosoftPhone implements Phone {
    public void display() {
        System.out.println("Nokia 3");
    }
}
